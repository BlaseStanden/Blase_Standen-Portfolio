Networking and User Interface Design ACW Readme
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Contents
========

This zip file contains both the location (client) and the locationserver (server).

Locations
============

locationserver\locationserver\bin\Debug -- locationserver.exe location
location\location\bin\Debug -- location.exe location
