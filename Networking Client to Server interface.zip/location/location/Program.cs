﻿using System;
using System.Net.Sockets;
using System.IO;

enum ProtocolType//Stores all the protocols
{
    Whois,
    HTTP09,
    HTTP10,
    HTTP11
}
struct InputData //Stores all the variables 
{
    internal string hostname, name, location;
    internal int port;
    internal int timeout;
    internal ProtocolType type;
}

public class Whois
{
    static void Main(string[] args)
    {
        InputData data = new InputData();
        data.name = data.location = null;
        data.hostname = "localhost";
        data.port = 43;
        ProtocolType type = ProtocolType.Whois;
        for (int i = 0; i < args.Length; i++)
        {
            switch (args[i])
            {
                case "-h9":
                    type = ProtocolType.HTTP09;
                    break;

                case "-h0":
                    type = ProtocolType.HTTP10;
                    break;

                case "-h1":
                    type = ProtocolType.HTTP11;
                    break;

                case "-h":
                    i++;
                    data.hostname = args[i];
                    break;

                case "-p":
                    i++;
                    data.port = int.Parse(args[i]);
                    break;
                case "-t":
                    i++;
                    data.timeout = int.Parse(args[i]);
                    break;
                default:
                    if (data.name == null)
                    {
                        data.name = args[i];
                    }
                    else
                    {
                        data.location = args[i];
                    }
                    break;
            }
        }
        try
        {
            TcpClient client = new TcpClient();

            client.ReceiveTimeout = data.timeout = 1000;
            client.SendTimeout = data.timeout = 1000;

            client.Connect(data.hostname, data.port);
            StreamWriter sw = new StreamWriter(client.GetStream());
            StreamReader sr = new StreamReader(client.GetStream());
            if (args.Length == 0)
            {
                Console.WriteLine("No arguments provided.");
            }
            else if (data.location == null)
            {
                switch (type)//A request from the client to the server for the server to query the database for a person's location
                {
                    case ProtocolType.HTTP09:
                        sw.WriteLine("GET" + " " + "/" + data.name);

                        break;
                    case ProtocolType.HTTP10:
                        sw.WriteLine("GET" + " " + "/?" + data.name + " " + "HTTP/1.0");
                        sw.WriteLine();
                        break;
                    case ProtocolType.HTTP11:
                        sw.WriteLine("GET" + " " + "/?name=" + data.name + " " + "HTTP/1.1");
                        sw.WriteLine("Host:" + " " + data.hostname);
                        sw.WriteLine();
                        break;
                    default:
                        sw.WriteLine(data.name);
                        break;
                }

                sw.Flush();
                string output;

                if (data.port == 80)
                {
                    output = "";
                    while (sr.Peek() > -1)
                    {
                        output += (char)sr.Read();
                    }
                }

                else
                {
                    output = sr.ReadToEnd();
                }

                if (output == "ERROR: no entries found\r\n")
                {
                    Console.WriteLine(output);
                }
                else
                {
                    string[] array = output.Split('\n');
                    switch (type)
                    {
                        case ProtocolType.HTTP09:
                            Console.WriteLine(data.name + " is " + array[array.Length - 2].TrimEnd('\r'));
                            break;
                        case ProtocolType.HTTP10:
                            Console.WriteLine(data.name + " is " + array[array.Length - 2].TrimEnd('\r'));
                            break;
                        case ProtocolType.HTTP11:
                            if (data.port == 80)
                            {
                                for (int i = 0; i < array.Length; i++)
                                {
                                    array[i] = array[i].TrimEnd('\r');
                                }

                                bool should_Add = false;
                                string html = string.Empty;
                                for (int i = 0; i < array.Length; i++)
                                {
                                    if (array[i] == "<html>")
                                    {
                                        should_Add = true;
                                    }
                                    if (should_Add)
                                    {
                                        html += array[i] + "\r\n";
                                    }
                                    if (array[i] == "</html>")
                                    {
                                        should_Add = false;

                                    }

                                }
                                Console.WriteLine(data.name + " is " + html);
                            }
                            else
                            {
                                Console.WriteLine(data.name + " is " + array[array.Length - 2].TrimEnd('\r'));
                            }
                            break;
                        default:
                            Console.WriteLine(data.name + " is " + output);//A request from the client to the server for the server to query the database for a person's location
                            break;
                    }

                }
            }
            else
            {
                switch (type)
                {
                    case ProtocolType.HTTP09:
                        sw.WriteLine("PUT /" + data.name);//A request from the client to the server for the server to update the database with a new location for a person 
                        sw.WriteLine("");
                        sw.WriteLine(data.location);
                        break;
                    case ProtocolType.HTTP10:
                        sw.WriteLine("POST" + " " + "/" + data.name + " " + "HTTP/1.0");
                        sw.WriteLine("Content-Length:" + " " + data.location.Length);
                        sw.WriteLine("");
                        sw.WriteLine(data.location);
                        break;
                    case ProtocolType.HTTP11:
                        string name_Location = "name=" + data.name + "&location=" + data.location;
                        sw.WriteLine("POST" + " " + "/" + " " + "HTTP/1.1");
                        sw.WriteLine("Host:" + " " + data.hostname);
                        sw.WriteLine("Content-Length:" + " " + name_Location.Length);
                        sw.WriteLine("");
                        sw.WriteLine(name_Location);
                        break;
                    default:
                        sw.WriteLine(data.name + " " + data.location);//A request from the client to the server for the server to update the database with a new location for a person
                        break;
                }

                sw.Flush();
                var output = sr.ReadToEnd();
                if (output == "OK\r\n")
                {
                    Console.WriteLine(data.name + " location changed to be " + data.location);
                }
            }

        }
        catch (Exception e)
        {
            Console.WriteLine("Something went wrong");
            Console.WriteLine(e.ToString());

        }


    }
}