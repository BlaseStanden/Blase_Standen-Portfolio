﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;

static class Whois
{
    static Dictionary<string, string> localDictionary = new Dictionary<string, string>(); //Server dictionary

    static void Main(string[] args)
    {
        runServer();
    }
    static void runServer()
    {
        TcpListener listener;
        Socket connection;
        NetworkStream socketStream;
        try
        {
            listener = new TcpListener(IPAddress.Any, 43);//server address and port
            listener.Start();
            Console.WriteLine("Server started Listening");//Waiting on the clients request
            while (true)//Once the clients connected
            {
                connection = listener.AcceptSocket();
                socketStream = new NetworkStream(connection);
                Console.WriteLine("Response Recived");
                doRequest(socketStream);
                socketStream.Close();
                connection.Close();
            }

        }
        catch (Exception e)
        {
            Console.WriteLine("Exception: " + e.ToString());
        }
    }
    static void doRequest(NetworkStream socketStream)
    {
        try
        {
            socketStream.ReadTimeout = socketStream.WriteTimeout = 1000;
            StreamWriter sw = new StreamWriter(socketStream);
            StreamReader sr = new StreamReader(socketStream);

            sw.AutoFlush = true;
            string line = "";

            while (sr.Peek() >= 0)
            {
                line += (char)sr.Read();
            }
            Console.WriteLine("Respond Recived: " + line);
            String[] sections = line.Split(new char[] { ' ', '\r', '\n' });
            
            String locations = sections[sections.Length - 1];
            if (sections[0] == "GET")
            {
                if (sections[2] == "HTTP/1.0")//HTTP 1.0 GET 
                {
                    if (localDictionary.ContainsKey(sections[1].TrimStart('/')))//If the dictionary contains a location for the person. Then trim forwardslash
                    {
                        sw.WriteLine("HTTP/1.0" + " " + "200" + " " + "OK");//When the client requests the server to query the database for a person's location
                        sw.WriteLine("Content-Type:" + " " + "text/plain");
                        sw.WriteLine("");
                        sw.WriteLine(localDictionary[sections[1]]);
                    }
                    else
                    {
                        sw.WriteLine("HTTP/1.0" + " " + "404" + " " + "Not" + " " + "Found");//When the client requests for the persons location but is able to find anthing in the database.
                        sw.WriteLine("Content-Type:" + " " + "text/plain");
                        sw.WriteLine("");
                    }

                }
                else
                {
                    if (sections[2] == "HTTP/1.1")//HTTP 1.1 GET
                    {
                        if (localDictionary.ContainsKey(sections[1]))
                        {
                            sw.WriteLine("HTTP/1.1" + " " + "200" + " " + "OK");//Same as HTTP 0.9 GET
                            sw.WriteLine("Content-Type:" + " " + "text/plain");
                            sw.WriteLine("");
                            sw.WriteLine(localDictionary[sections[1]]);
                        }

                        else
                        {
                            sw.WriteLine("HTTP/1.1" + " " + "404" + " " + "Not" + " " + "Found");
                            sw.WriteLine("Content-Type:" + " " + "text/plain");
                            sw.WriteLine("");
                        }
                    }

                    else
                    {
                        if (localDictionary.ContainsKey(sections[1]))//HTTP 0.9 GET
                        {
                            sw.WriteLine("HTTP/0.9" + " " + "200" + " " + "OK");//When the client requests the server to query the database for a person's location
                            sw.WriteLine("Content-Type:" + " " + "text/plain");
                            sw.WriteLine("");
                            sw.WriteLine(localDictionary[sections[1]]);
                        }

                        else
                        {
                            sw.WriteLine("HTTP/0.9" + " " + "404" + " " + "Not" + " " + "Found");//When the client requests for the persons location but is able to find anthing in the database.
                            sw.WriteLine("Content-Type:" + " " + "text/plain");
                            sw.WriteLine("");
                        }
                    }
                }
            }
            else if (sections[0] == "PUT")//HTTP 0.9 PUT
            {
                
                sw.WriteLine("HTTP/0.9" + " " + "200" + " " + "OK");
                sw.WriteLine("Content-Type:" + " " + "text/plain");
                sw.WriteLine("");
                if (localDictionary.ContainsKey(sections[0]))
                {
                    localDictionary[sections[1].TrimStart('/')] = locations.TrimStart('/');
                }
                else
                {    
                    localDictionary.Add(sections[1].TrimStart('/'), locations.TrimStart('/'));
                }

            }
            else if (sections[0] == "POST")
            {
                if (sections[2] == "HTTP/1.0")//HTTP 1.0 PUT
                {
                    
                    sw.WriteLine("HTTP/1.0" + " " + "200" + " " + "OK");
                    sw.WriteLine("Content-Type:" + " " + "text/plain");
                    sw.WriteLine("");
                    if (localDictionary.ContainsKey(sections[0]))
                    {
                        localDictionary[sections[1]] = locations.TrimStart('/');
                    }
                    else
                    {
                        localDictionary.Add(sections[1], locations.TrimStart('/'));
                    }
                }
                else//HTTP 1.1 PUT
                {
                    
                    sw.WriteLine("HTTP/1.1" + " " + "200" + " " + "OK");
                    sw.WriteLine("Content-Type:" + " " + "text/plain");
                    sw.WriteLine("");
                    if (localDictionary.ContainsKey(sections[0]))
                    {
                        localDictionary[sections[1]] = locations.TrimStart('/');
                    }
                    else
                    {
                        localDictionary.Add(sections[1], locations.TrimStart('/'));
                    }
                }
            }
            else
            {
                switch (sections.Length)
                {
                    case 1:
                        try
                        {
                            
                            if (localDictionary.ContainsKey(sections[0]))
                            {
                                foreach (KeyValuePair<string, string> info in localDictionary)
                                {
                                    if (info.Key == sections[0])
                                    {
                                        sw.WriteLine(info.Value);
                                    }
                                }
                            }
                            else
                            {
                                sw.WriteLine("ERROR: no entries found");
                            }
                        }
                        catch
                        {
                            throw new Exception("Something went wrong...");
                        }
                        break;
                    case 2:
                        switch (sections[0])
                        {
                            default:
                                if (localDictionary.ContainsKey(sections[0]))
                                {
                                    localDictionary.Remove(sections[0]);
                                    localDictionary.Add(sections[0], sections[1]);
                                    sw.WriteLine("OK");
                                }
                                else
                                {
                                    localDictionary.Add(sections[0], sections[1]);
                                    sw.WriteLine("OK");
                                }
                                break;
                        }
                        break;
                }
            }

            sw.Flush();
        }
        catch (Exception)
        {

            Console.WriteLine("Something went wrong.");

        }


    }
}
